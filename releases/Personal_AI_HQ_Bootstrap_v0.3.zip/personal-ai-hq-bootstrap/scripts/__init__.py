"""Verification scripts package."""
